import { asyncHandler } from '../../../common/utils/asyncHandler.js'
import * as inboxService from '../services/riderInbox.service.js'
import * as rideService from '../services/ride.service.js'
import { Trip } from '../models/Trip.js'
import { User } from '../../users/user.model.js'

export const openRequests = asyncHandler(async (req, res) => {
  const isApprovedRider = req.user.role === 'rider'
  const rider = await User.findById(req.user.id).lean()
  const capacityPassengers = Math.max(0, Number(rider?.seatCount ?? 0))
  const activeTrips = await Trip.find({
    riderId: req.user.id,
    status: { $in: ['to_pickup', 'to_university', 'overdue'] },
  }).lean()
  const used = activeTrips.reduce((sum, t) => sum + Number(t.seatCount ?? 1), 0)
  const remainingSeats = Math.max(0, capacityPassengers - used)
  const isOnline = rider?.availability === 'online'

  const items = await inboxService.listOpenRequests({
    campusId: rider?.campusId ?? req.user.campusId ?? req.query?.campusId ?? null,
  })
  const withAccept = items.map((r) => {
    const need = Number(r.seatCount ?? 1)
    const canAccept =
      isApprovedRider && isOnline && need <= remainingSeats && capacityPassengers > 0
    let acceptBlockedReason = null
    if (!canAccept) {
      if (!isApprovedRider) acceptBlockedReason = 'pending_approval'
      else if (!isOnline) acceptBlockedReason = 'offline'
      else if (capacityPassengers <= 0) acceptBlockedReason = 'no_capacity'
      else if (need > remainingSeats) acceptBlockedReason = 'not_enough_seats'
    }
    return { ...r, canAccept, remainingSeats, acceptBlockedReason }
  })
  res.json({ success: true, data: withAccept })
})

export const dashboard = asyncHandler(async (req, res) => {
  const data = await rideService.getRiderDashboard({
    riderUserId: req.user.id,
    campusId: req.user.campusId ?? null,
  })
  res.json({ success: true, data })
})

